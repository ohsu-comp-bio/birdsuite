# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright 2008 by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

#GOAL:
#the initial cluster algorithms to take the raw intensity data and turn it into some labled data.  
#This data is completely unfiltered by quality, but will should have an uncertainty metric associated with it.

#the input is one or more target files, which produce a matrix of results, where the first column is labeled "cnp_id", and subsequent columns are named for some identifier, such as the cel or sample name.  Each row represents one CNP worth of data for all the samples that exist in the initial data set.

#source ("CNP_IO.R")
#source ("CNP_Canary.R")
#library(mclust02)

#profileList <-list("/humgen/cnp04/sandbox/data/HAPMAP2/pipeline/GIGAS/GIGAS.probeset_summary")
#outDir="."
#priorsFile="/humgen/affy_info/GAPProduction/dev/GenomeWideSNP_6.hg17.canary_priors"
#offsetFile="/humgen/affy_info/GAPProduction/dev/GenomeWideSNP_6.canary_offsets"

#read in profiles.  If there is more than one, and they don't have the same set of CNPs, return NULL.
#cluster them according to one of the clustering algorithms.
#the return is a list of matrixes, one for each data type the clustering algorithm in question returns.
#If the outDir is specified, the matrixes of data are written out to a file.
#If an invalid method is specified, this function returns NULL.
# ... arguments are passed on to a particular method like canary
cnp_clustering.cluster <-function (profileList, method="CANARY", priorsFile=NULL, offsetFile=NULL, outDir=NULL, verbose=T, params=NULL, ...) {
	if (!file.exists(outDir)) if (!dir.create(outDir)) cat (paste("could not make directory", outDir, '\n')) 
	
	if (length (profileList) > 1) {
		profileDFs<-sapply (profileList, cnp_io.readProfileFile)
		if (cnp_io.validateProfileList(profileDFs, T)==F) return (NULL)
	} else profileDFs<-list(cnp_io.readProfileFile(profileList[[1]]))
        
	lens<-sapply (profileDFs, function (x) dim(x)[1])
	cat (paste ('Profile size', lens, '\n'))
        if (!is.null(offsetFile)) {
	   offsetDF<-read.table(offsetFile, header=T, row.names=1, stringsAsFactors=F)
	} else {
	   offsetDF=NULL
	}

	if (method=="GMM") {
		#super hack.
		library(mclust02)
		result<-cnp_clustering.clusterProfiles(profileDFs, 
			clusteringAlgorithm=cnp_clustering.gmmSingleCNPVerbose, verbose)
	} else if (method=="CANARY") {
		#if priors exist, read priors in here.
		if (is.null(priorsFile)) priors=NULL else priors<-read.table(priorsFile,header=T,row.names=1)
		
		result<-cnp_clustering.clusterProfiles(profileDFs, 
			clusteringAlgorithm=cnp_clustering.fkSingleCNPVerbose, verbose, priors, outDir, offsetDF, params, ...)
	} else {
		cat (paste("Method not found", method, '\n'))
		result<-NULL
	}
	if (!is.null(outDir) && !is.null(result)) cnp_clustering.writeResultsToFile(result, outDir)
	return (result)
}

#profileDF<-profileDFs[[1]]

#THIS RUNS ANY OF THE CLUSTERING ALGORITHMS.

#returns a list of matrixes, one for each attribute produced by the clustering algorithm.
#the algorithm to plug in is either cnp_clustering.gmmSingleCNPVerbose or cnp_clustering.fkSingleCNPVerbose
#any extra args are passed on to the singleCNPVerbose clustering argument.
cnp_clustering.clusterProfiles<-function (profileDFs, clusteringAlgorithm=cnp_clustering.fkSingleCNPVerbose, verbose=F, priors, outDir, offsetDF, params) {

	result<-list()
	for (i in 1:length(profileDFs)) {
		profileDF<-profileDFs[[i]]
		#if the file being passed in has CNV location, cut out the location columns.
		#intensitiesDF<-cnp_io.readProfileIntensities(profileDF)
		#otherwise, just repoint.
		intensitiesDF<-profileDF[,-1]
		rownames(intensitiesDF)=profileDF$cnp_id
		clusterResult<-lapply (1:dim (intensitiesDF)[1], clusteringAlgorithm, intensitiesDF, verbose, priors, offsetDF, outDir, params)
		cat('Finished Clustering process','\n')
		listResult<-cnp_clustering.bindResultsToMatrix(clusterResult)
		
		for (i in 1:length(listResult)) {
		   if (dim(listResult[[i]])[2]!=length(colnames(intensitiesDF))) {
		     cat(paste("CNP ", i, "has different number of results  and colnames", '\n'))
		   }
		   colnames(listResult[[i]])<-colnames(intensitiesDF)
	        }
		if (length(result)==0) result<-listResult
		else for (i in 1:length(result)) result[[i]]<-cbind(result[[i]], listResult[[i]])
	}
	cnpIDs<-paste(profileDFs[[1]]$cnp_id, sep="")
	
	for (i in 1:length(result)) result[[i]]<-data.frame(result[[i]], check.names=F)
	for (i in 1:length(result)) rownames (result[[i]])<-cnpIDs
	return (result)	
}


#####################
# CLUSTERING ALGORITHMS TAKE IN some info for a single CNP, and return a list of vectors for each attribute of that CNP .  Example: GMM takes in intensity data, and returns a list with 2 vectors: uncertainty and label.
# Each vector will be transformed properly into a nice matrix for output.
#####################


################################
# FINNY K METOD
################################

#defers to gmmSingleCNP, but handles logging of what CNP you're processing.
cnp_clustering.fkSingleCNPVerbose <-function (index, intensitiesDF, verbose=F, priors=NULL, offsetDF, outDir, params) {
	intensitiesOneCNP<-intensitiesDF[index,]
	cnvName<-rownames(intensitiesOneCNP)

	if (verbose && index%%1==0) cat (paste("Canary Clustering index", index, cnvName, '\n'))
	
	if (is.null(priors)) return (cnp_clustering.fkSingleCNP(intensitiesOneCNP, NULL))
	#THIS IS A HACKY INTERMEDIATE SOLUTION...
       	if (!any(rownames(priors)==cnvName)) {
	   cat (paste (cnvName, "ignored because it does not have required priors", '\n', sep=" ") )
	   l<-length(intensitiesOneCNP)
	   t<-list(genotypes=rep(NA, l), uncertainty=rep(NA,l))  
	   return (t)
	}

	#you must have priors to get here. 	
	p<-priors[cnvName,]
	cat (paste ('Using priors for CNV', rownames (p), '\n'))
	result<-cnp_clustering.fkSingleCNP(intensitiesOneCNP, p, outDir, params)
	#for CNVs that don't scale from 0-4, add an offset.
	if (any(rownames(offsetDF)==cnvName)) {
        	offset=offsetDF[cnvName,1]
		result$genotypes<-result$genotypes+offset
		cat('offset added for cnv', cnvName, offset,'\n')

        }
	return (result)

}


#returns a list with however many elements.
#this defers to the canary source.
#intensitiesOneCNP<-intensities[1,]
cnp_clustering.fkSingleCNP<-function (intensitiesOneCNP, p, outDir, params){
	#i<-as.double (intensitiesOneCNP)
	if (is.null(p)) {
	   r<-em_canary_no_prior(intensitiesOneCNP,...) 
	   fr<-list(initialAssignments=r$assignments, uncertainty=r$confidences)
	} else {
	   r<-em_canary_with_prior(intensitiesOneCNP,p, outDir=outDir, params=params)
	   fr<-list(genotypes=r$assignments, uncertainty=r$confidences)
	}
	return (fr)
}

############################
# GMM 
############################

cnp_clustering.gmmSingleCNPVerbose <-function (index, intensitiesDF, verbose=F, ...) {
	if (verbose && index%%100==0) cat (paste("GMM Clustering index", index, '\n'))
	intensitiesOneCNP<-intensitiesDF[index,]
	result<-cnp_clustering.gmmSingleCNP(intensitiesOneCNP)
	return (result)
}


#GMM method of clustering CNPs.
cnp_clustering.gmmSingleCNP <- function(intensitiesOneCNP, ...) {
  # Input x is the vector of CN measurements to be clustered
  # Do EM clustering for G=1:7 (if clusters not well-spaced, drop down to lower G)
  
  x<-as.double (intensitiesOneCNP)
  max_clusters <-7 
  repeat {
     result1 <- EMclust(data=x, G=1:max_clusters, emModelNames=c("E") )
     result <- summary( result1, data=x )

     # Resort the clusters s.t. cluster 1 corresponds to lowest CN class, cluster 2 to next lowest, etc.
     result$mu <- tapply( x, result$classification, mean )
     resort <- sort(result$mu, index.return=T)$ix
     centers <- as.vector (result$mu[resort])

     # If the clusters are not close to evenly spaced, we're overfitting -- drop down to a smaller G and try again
     #    otherwise, break
     dist_between_centers <- 0
     centerMaxDistance=2.0
     if(length(centers) >= 2) dist_between_centers <- centers[2:length(centers)] - centers[1:(length(centers)-1)]
     if((length(centers) <= 2) | (max(dist_between_centers) < centerMaxDistance*min(dist_between_centers) )) break
     max_clusters <- max_clusters - 1
   }

   assignments <- as.integer (match( result$classification, as.numeric( names(result$mu) )[resort] ))
   clusters <- length(centers)
   variances <- tapply(x, assignments, var)
   variances[ is.na(variances) ] <- 0.01
   counts <- tapply(x, assignments, length)
	
   # Return results
   result<-list(uncertainty=result$uncertainty, initialAssignments=assignments, intensities=x)
   return (result)
}

##################
# HELPER FUNCTIONS
##################

#A clusterResultList is a matrix with 1 row per return type in the clustering algorithm return list, and each column contains a list element with a vector of one of the results, so this is a matrix with 2 dimensions, and each element of the matrix is single element list of a vector of numbers.
#Transform the results from this funky matrix into a list with 1 element for each attribute returned from the clustering result list, bound as a 'normal' 2d matrix.
cnp_clustering.bindResultsToMatrix<-function (clusterResult) {
	result<-list()
	attributeNames<-names(clusterResult[[1]])
	for (i in 1:length(attributeNames)) {
		atrib<-attributeNames[i]
		#data List is a list of an attribute, with each element of vector for that CNP.
	        dataList<-lapply (clusterResult, function (x) x[[atrib]])		
		resultMatrix<-do.call(rbind, dataList)
		result[[atrib]]<-resultMatrix
	}
	cat ('Results Bound to Matrixes', '\n')
	return (result)
}

#This takes the results, as bound up by cnp_clustering.bindResultsToMatrix, and writes them to a directory.
cnp_clustering.writeResultsToFile<-function (result, outDir=".") {
	cat ('Writing to file', '\n')
	for (i in 1:length(result)) {
		n<-names(result)[i]
		data<-result[[i]]
		
		outName<-paste(outDir, "/allData_", n, ".txt", sep="")
		d2<-data.frame(cbind (cnp_id=rownames(data), data),check.names=F)
		write.table(d2, outName, row.names=F, col.names=T, quote=F, sep="\t")
	}
	cat ("Results written", '\n')
}
