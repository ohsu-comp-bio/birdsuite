# To-do: comment code, optimize params, esp. # of pseudopoints
# eliminate unnecessary functions, stress test, rewrite estep

library(mclust)  # This program uses only one function from mclust: estep,
                 # which wraps some Fortran code; recode estep later in C++
                 # because mclust has licensing issues

max_clusters <- 5   # Warning! You cannot simply change this number
                    # and alter the programs ability to do clustering.
                    # This number is deeply coded into the program in
                    # multiple places, because of having to test
                    # individual models.  However at a few places this
                    # constant is used.

# Parameters from in fill_clusters.R
average_power <- 0.729
slope01 <- 0.3314739
slope12 <- 0.2154641
slope23 <- 0.1645835
slope34 <- 0.1571859
slopes <- c(slope01,slope12,slope23,slope34)

min_variance <- 1e-4
trailoff_par <- 3

use_af <- FALSE # if TRUE, will only test certain models based
                # on the AF of the prior and imputation will occur
                # in a directional fashion, ie towards probability density

graphing <- FALSE
if(graphing) {
  par(cex.main=1)
  par(cex=0.8)
}

trailoff_fxn <- function(x) {
  1/(1 + exp(trailoff_par - x)) - 1/(1 + exp(trailoff_par))
}

second_biggest <- function(x) {
  x[which(x == sort(x)[length(x)-1])][1]
}

confidence_relative_to_cluster <- function(mean,sigmasq,x) {
  inv_var <- 1/sigmasq
  delta <- x - mean
  std_dist <- sqrt((delta^2 * inv_var)/2)
  trailoff_fxn(std_dist)
}

confidence_scores <- function(x,params,z) {
  rel_conf_weight <- 0.8
  global_confidences <- sapply(1:nrow(z),
                        function(i) second_biggest(z[i,])/max(z[i,]))
  local_confidences <- numeric(length(global_confidences))
  m <- sapply(1:nrow(z),function(i) which(z[i,]==max(z[i,])))
  for(k in seq(1,length(global_confidences))) {
    local_confidences[k] <-
      confidence_relative_to_cluster(params$mean[m[k]],
                                     params$variance$sigmasq[m[k]],
                                     x[k])
  }
  confidences <- rel_conf_weight * global_confidences +
    (1 - rel_conf_weight) * local_confidences
  confidences
}

geom_mean <- function(x) {
  exp(mean(log(as.numeric(x)),na.rm=TRUE))
}

##################

hist_cnv <- function(x,results,cnv_name=NULL,fullprior=NULL,extratext) {
  cols <- c('blue','red','green','magenta','cyan','black','yellow','violetred')
  if(!is.null(fullprior)) {
    fullprior_means <- as.numeric(fullprior[c('M0','M1','M2','M3','M4')])
    fullprior_vars <- as.numeric(fullprior[c('V0','V1','V2','V3','V4')])
    max_x <- max(1.1 * max(fullprior_means),1.1 * max(x))
  } else {
    max_x <- 1.1 * max(x)
  }
  clusters <- results$clusters
  confidences <- results$confidences
  G <- length(clusters$mean)
  genotypes <- results$assignments
  uniq_genotypes <- sort(unique(genotypes))
  par(mfrow=c(2,1))
  tstring <- paste(cnv_name,': ',toString(uniq_genotypes),extratext)
  hist(x,breaks=100,xlab='Intensity',main=tstring,xlim=c(0,max_x))
  leg.txt <- c()
  leg.cols <- c()
  for(g in uniq_genotypes) {
    desired <- which(genotypes == g)
    rug(x[desired],col=cols[g + 1])
    leg.txt <- c(leg.txt,as.character(g))
    leg.cols <- c(leg.cols,cols[g + 1])
  }
  legend("topleft",leg.txt,col=leg.cols,lty=1)
  xpoints <- seq(0,max_x,length.out=500)
  for(k in seq(G)) {
    ypoints <- 3 * clusters$prop[k] * dnorm(xpoints,mean=clusters$mean[k],
                     sd=sqrt(clusters$sigmasq[k]))
    lines(xpoints,ypoints)
  }
  if(!is.null(fullprior)) {
    fullprior_means <- as.numeric(fullprior[c('M0','M1','M2','M3','M4')])
    fullprior_vars <- as.numeric(fullprior[c('V0','V1','V2','V3','V4')])
    for(k in seq(max_clusters)) {
      ypoints <- 1.5 * dnorm(xpoints,
                           mean=fullprior_means[k],
                           sd=sqrt(fullprior_vars[k]))
      lines(xpoints,ypoints,col=cols[k],lty=2)
    }
  }
  if(!(all(is.na(results$confidences)))) {
    plot(x,results$confidences,xlim=c(0,max_x),
         xlab='Intensities',ylab='Confidences')
    lines(c(0,max_x),c(0.1,0.1))
  } else {
    plot(x,results$confidences,xlim=c(0,max_x),ylim=c(0,.2),
         xlab='Intensities',ylab='Confidences')
    lines(c(0,max_x),c(0.1,0.1))
  }
}


#limit variances to grow by at most the limit (say 30%) greater than the priors variance.
#pass in 0 to skip this step.
constrain_variance<-function (prior, sigmasq, limit=1.3) {
   result<-list(constrained=F, sigmasq=sigmasq)

   if (limit==0) return (result)
   constrained<-prior$sigmasq*limit
   z<-sapply (1:length(sigmasq), function (x) min (sigmasq[x], constrained[x]))
   if (any(z==constrained)) result<-list(constrained=T, sigmasq=z)

   return (result) 
}

# ** This should be weighted by number of points in each cluster!
# Could during the EM loop fit a line based on cluster mean versus cluster
# standard deviation.

regularize_variances <- function(variances,pro=NULL) {  
  var_reg = 4/10  # 0 is unregularized, 1 is identical variances
  G = length(variances)
  new_vars <- sapply(1:G,function (i) (1-var_reg) * variances[i] +
                      var_reg * mean(variances))
  new_vars
}

order_variances <- function(variances) {
  new_vars <- sort(variances)
}

gmm_noprior <- function(x,G=2,verbose=TRUE) {
  n <- length(x)  # how many points are in the dataset
  d <- 1  # dimensionality of the data
  loglik_threshold <- 1e-4
  max_iter <- 100
  min_iter <- 10
  delta_loglik <- 10 * loglik_threshold

  if(G == 1) {
    mean = median(x)
  } else {
    mean = seq(min(x),max(x),length.out=G)
  }

  sigmasq <- rep(sd(x)/G,G)
  pro <- rep(1,G)/G
  
  variance <- list(d=d,G=G,sigmasq=sigmasq)
  parameters <- list(pro=pro,mean=mean,variance=variance)
  loglik <- -Inf
  old_loglik <- 0
  iterations <- 0

  while(((iterations < max_iter) && (abs(delta_loglik) > loglik_threshold))
        || (iterations < min_iter)) {
    model <- estep('V',x,parameters)

    loglik <- model$loglik
    # z contains the posterior probabilities
    z <- model$z

    pro <- apply(z,2,mean)
    mean <- apply(z * x, 2, sum)/apply(z, 2, sum)
    sigmasq <- sapply(1:G, function(i)
                      sum(z[,i] * (x - mean[i])^2)/apply(z, 2, sum)[i])

    sigmasq <- regularize_variances(sigmasq,pro)
    sigmasq <- order_variances(sigmasq)
    
    variance <- list(d=d,G=G,sigmasq=sigmasq)
    parameters <- list(pro=pro,mean=mean,variance=variance)

    delta_loglik <- loglik - old_loglik
    old_loglik <- loglik
    iterations <- iterations + 1
    cat ('Iteration', iterations, '\n')
    print (parameters)
  }
  if(verbose) cat("Number of iterations:",iterations,'\n')
  list(prop=parameters$pro,mean=parameters$mean,
       sigmasq=parameters$variance$sigmasq,loglik=loglik)
}


#ratioDtaUsed is the amount of data used to find the mean intensity.  Setting to 1 = all data.
#another setting to try is 0.95

gmm_withprior <- function(x,prior,params, verbose=TRUE, ratioDataUsed=1) {
  cat ('starting gmm\n')
  #cat ('x ', x, '\n')

  pseudopointFactor<-as.numeric (params$pseudopointFactor)
  n <- length(x)  # how many points are in the dataset
  d <- 1  # dimensionality of the data
  loglik_threshold <- 1e-2
  min_iter <- 10
  max_iter <- 100
  delta_loglik <- 10 * loglik_threshold
  cluster_vec<-prior$cluster_vec # which cluster setup is being used?
  G <- prior$G
  #mean <- prior$mean

  #mean can be robust, where it uses the freq of the priors and the actual data to place the cluster centers.
  #if the model tested is 1 cluster center, put the center in the median.
  if(G == 1) {
    mean = median(x)
  } else if (params$robust_means) { 
    # mean uses the freq of the priors and the intensity data to guess where to put the means.
    x2<-sort (x)
    startIdx=ceiling (prior$pro[1]*length(x)/2)
    endIdx= length(x) - floor (prior$pro[length(prior$pro)]*length(x)/2) 
    x2<-x2[startIdx:endIdx]
    mean = seq(as.numeric(quantile(x2,(1-ratioDataUsed))),as.numeric(quantile(x2,ratioDataUsed)),
      length.out=G)
    cat ('Robust means', mean, '\n')
  } else {
     mean = seq(as.numeric(quantile(x,(1-ratioDataUsed))),as.numeric(quantile(x,ratioDataUsed)),
           length.out=G)
     cat ('Default mean', mean, '\n')
  }
  
  pro <- rep(1/G,G)
  sigmasq <- prior$sigmasq
  num_pseudopoints <- prior$num_pseudopoints * pseudopointFactor
  # cat ('GMM with prior Starting num pseudopoints', num_pseudopoints, '\n')
  variance <- list(d=d,G=G,sigmasq=9 * sigmasq)
  parameters <- list(pro=pro,mean=mean,variance=variance)
  loglik <- -Inf
  old_loglik <- 0
  iterations <- 0
  cat ('prior variance' , sigmasq, '\n') 
  isVarianceConstrained<-F

  while(((iterations < max_iter) && (abs(delta_loglik) > loglik_threshold))
        || (iterations < min_iter)) {
    
    #print (parameters)
    
    model <- estep('V',x,parameters)
    #print (model)

    loglik <- model$loglik
    # z contains the posterior probabilities
    z <- model$z

    #experimental fix for 0 level probabilities?
    #z<-apply (z, c(1,2), function (x) max(x, 1e-100))
    
    #other experimental fix for 0 level probabilities
    #classProbCount=apply (z,2,sum)
    #if (any (classProbCount==0)) {
    #  cat ('one of the models had all 0 probabilities','\n')
    #  iterations=max_iter #this ends here.
    #} else {

       #cat ('probabilities (z) ', z, '\n')
    
       pro <- apply(z,2,mean)

       # So here could scale the number of pseudopoints
       num_pseudopoints <- pmin(apply(z,2,sum) * .1,num_pseudopoints)
       #cat('GMM with prior Num pseudopoints: ',num_pseudopoints,'\n')
    
       #mean <- (apply(z * x, 2, sum) + prior$mean * num_pseudopoints) /
       #  (apply(z, 2, sum) + num_pseudopoints)
 
       #yet another solution, this one provided by Finny:
       eps<-1e-6
       mean <- (apply(z * x, 2, sum) + prior$mean * num_pseudopoints) /
	     (apply(z, 2, sum) + num_pseudopoints + eps)

       #cat('Mean: ',mean,'\n')
    
       sigmasq <- sapply(1:G, function(i)
                  sum(z[,i] * (x - mean[i])^2)/apply(z, 2, sum)[i])

    
       # Note that the sigmasq can have NaNs in them if the data do not
       # have points where the priors locations are.  Thus set those cases
       # to be the min_variance

       sigmasq[is.na(sigmasq)] <- min_variance
       cv<-constrain_variance(prior, sigmasq, limit=params$constrain_variance)
       sigmasq<-cv$sigmasq
       if (cv$constrained) isVarianceConstrained<-T

       sigmasq <- regularize_variances(sigmasq,pro)
    
       #cat('Variance: ',sigmasq,'\n')

       ordering <- order(mean)
       mean <- mean[ordering]
       sigmasq <- sigmasq[ordering]
       pro <- pro[ordering]

       variance <- list(d=d,G=G,sigmasq=sigmasq)
       parameters <- list(pro=pro,mean=mean,variance=variance)
    
       delta_loglik <- loglik - old_loglik
       old_loglik <- loglik
       iterations <- iterations + 1
    #}
  }

  #if(verbose) cat("Number of iterations:",iterations,'\n')
  if (isVarianceConstrained) cat ('variance constrained to ', sigmasq, '\n')
  list(prop=parameters$pro,mean=parameters$mean,
       sigmasq=parameters$variance$sigmasq,loglik=loglik)
}


models <- function(x) {
  n <- length(x)
  max_clusters <- 5
  m <- lapply(1:max_clusters,function(i) gmm_noprior(x,G=i))
  m
}

signif <- 0.05 # significance level for confidence intervals

conf_interval <- function(sigmasq,alpha=signif) {
  2 * qnorm(1-alpha/2) * sqrt(sigmasq)
}

bottom_interval <- function(mean,sigmasq,alpha=signif) {
  mean - qnorm(1-alpha/2) * sqrt(sigmasq)
}

top_interval <- function(mean,sigmasq,alpha=signif) {
  mean + qnorm(1-alpha/2) * sqrt(sigmasq)
}

# Interference is how much the Gaussians overlap
interference_model <- function(new_mean,new_sigmasq) {
  inflation <- 1.3  # how much to weight your interference by [1.2 works well]
  verbose <- FALSE
  G <- length(new_mean)

  if(verbose) cat('G: ',G,'\n')
  if (G > 1) {
    # First compute the total confidence intervals
    intervals <- sapply(1:G, function(i) conf_interval(new_sigmasq[i]))

    total_intervals <- sum(intervals)
    if (verbose) {
      cat('Intervals: ',intervals,'\n')
      cat('Total intervals: ',total_intervals,G,'\n')
    }

    cluster_overlap <- function(i) {
      max(top_interval(new_mean[i],new_sigmasq[i]) - 
          bottom_interval(new_mean[i+1],new_sigmasq[i+1]),0)
    }
    
     # Next find the overlap of the intervals
    overlaps <- unlist(sapply(1:(G-1),function(i) cluster_overlap(i)))
    total_overlaps <- sum(overlaps)
    interference <- total_overlaps / total_intervals

    if (verbose) {
      cat(overlaps,'\n')
      cat(total_overlaps,'\n')
      cat('Interference: ',interference,'\n')
    }

  } else {
    interference <- 0
  }
  interference * inflation
}

spacing_fail <- function(new_mean,new_sigmasq) {
  G <- length(new_mean)
  if (G > 3) {
    failure <- 125  # how much to penalize malspaced clusters
    gaps <- diff(new_mean)
    if (all(gaps == sort(gaps,decreasing=TRUE)))
      spacing <- 0
    else spacing <- failure
  } else spacing <- 0
  spacing
}  

spacing_model <- function(new_mean,new_sigmasq) {
  spacing_transition <- 0.05 # Above this you are penalized, below it you
                             # are helped
  spacing_effect <- 1.5  # A constant multiplier to modulate your effect
  
  G <- length(new_mean)
  if (G > 2) {
    normalized_diffs <- diff(new_mean)/new_mean[2:G]
    mean_normalized_diffs <- mean(normalized_diffs)
    spacing_param <- max((normalized_diffs - mean_normalized_diffs)^2)

    if (spacing_param > 0.08) {
      cat('Spacing aberrant!',spacing_param,G,'\n')
      cat('Spacing parameter:',spacing_param,'\n')
      spacing <- -1 * spacing_param * spacing_effect
    } else {
      spacing <- spacing_param * spacing_effect
      cat('New mean: ',new_mean,'\n')
      cat('Raw diffs: ',diff(new_mean),'\n')
      cat('Normalized diffs: ',normalized_diffs,'\n')
      cat('Spacing param: ',spacing_param,'\n')
    }
  } else spacing <- 0
  cat('Spacing',G,': ',spacing,'\n')
  spacing
}  

simplify_model <- function(m) {
  this_verbose <- FALSE
  mean_vector <- m$mean
  prop_vector <- m$prop
  sigmasq_vector <- m$sigmasq

  ordering <- order(mean_vector)
  mean_vector <- mean_vector[ordering]
  prop_vector <- prop_vector[ordering]
  sigmasq_vector <- sigmasq_vector[ordering]
  
  unique_means <- unique(mean_vector)

  same <- function(k1,k2) {
    overlap_threshold = 0.6
    overlap <- max(top_interval(mean_vector[k1],sigmasq_vector[k1]) - 
          bottom_interval(mean_vector[k2],sigmasq_vector[k2]),0)
    span1 <- top_interval(mean_vector[k1],sigmasq_vector[k1]) - 
             bottom_interval(mean_vector[k1],sigmasq_vector[k1])
    span2 <- top_interval(mean_vector[k2],sigmasq_vector[k2]) - 
             bottom_interval(mean_vector[k2],sigmasq_vector[k2])
    if(this_verbose) {
      cat('Overlap% ',k1,k2,overlap,span1,span2,
          overlap/span1,overlap/span2,'\n')
    }
    if(overlap/span1 > overlap_threshold ||
       overlap/span2 > overlap_threshold) TRUE else FALSE
  }

  if (length(mean_vector) > 1) {
    new_prop <- prop_vector[1]
    new_mean <- mean_vector[1]
    new_sigmasq <- sigmasq_vector[1]
    active_index <- 1
    for (k in 2:length(mean_vector)) {
      if(same(k-1,k)) {
        new_mean[active_index] <-
          (new_prop[active_index] * new_mean[active_index] +
           prop_vector[k] * mean_vector[k]) /
             (new_prop[active_index] + prop_vector[k])
        new_sigmasq[active_index] <-
          (new_prop[active_index] * new_sigmasq[active_index] +
           prop_vector[k] * sigmasq_vector[k]) /
             (new_prop[active_index] + prop_vector[k])
        # Must put this after the means are corrected
        new_prop[active_index] <- new_prop[active_index] + prop_vector[k]
      } else {
        new_prop <- c(new_prop,prop_vector[k])
        new_sigmasq <- c(new_sigmasq,sigmasq_vector[k])
        new_mean <- c(new_mean,mean_vector[k])
        active_index <- active_index + 1
      }
    }
  } else {
    new_prop <- prop_vector
    new_mean <- mean_vector
    new_sigmasq <- sigmasq_vector
  }
  ordering <- order(new_mean)
  new_mean <- new_mean[ordering]
  new_prop <- new_prop[ordering]
  new_sigmasq <- new_sigmasq[ordering]
  G <- length(new_mean)
  interference <- interference_model(new_mean,new_sigmasq)

  m <- list(prop=new_prop,mean=new_mean,sigmasq=new_sigmasq,G=G,
            loglik=m$loglik,interference=interference)
  m
}

selectmodel_noprior <- function(x,verbose=verbose) {
  this_verbose <- FALSE
  n <- length(x)
  max_clusters <- 5
  m <- lapply(1:max_clusters,function(i) gmm_noprior(x,G=i,verbose=verbose))

  m_old <- m
  
  m <- lapply(1:max_clusters,function(i) simplify_model(m[[i]]))

  # You need to recalculate the log-likelihood given the new params
  for(k in 1:max_clusters) {
    variance <- list(d=1,G=m[[k]]$G,sigmasq=m[[k]]$sigmasq)
    parameters <- list(pro=m[[k]]$prop,mean=m[[k]]$mean,variance=variance)
    model <- estep('V',x,parameters)
    m[[k]]$loglik <- model$loglik
  }

  if (this_verbose) {
    for(k in 1:max_clusters) {
      cat('Old prop vector: ',m_old[[k]]$prop,'\n')
      cat('New prop vector: ',m[[k]]$prop,'\n')
      cat('Old mean vector: ',m_old[[k]]$mean,'\n')
      cat('New mean vector: ',m[[k]]$mean,'\n')
      cat('Old sigmasq vector: ',m_old[[k]]$sigmasq,'\n')
      cat('New sigmasq vector: ',m[[k]]$sigmasq,'\n')
      cat('Old likelihood: ',m_old[[k]]$loglik,'\n')
      cat('New likelihood: ',m[[k]]$loglik,'\n')
    }
  }
  
  score <- numeric()
  stats=data.frame(G=c(rep(NA,max_clusters)),
    loglik=c(rep(NA,max_clusters)),
    bic=c(rep(NA,max_clusters)),
    interference=c(rep(NA,max_clusters)),
    spacing=c(rep(NA,max_clusters)),
    final=c(rep(NA,max_clusters)))
  
  for(k in 1:max_clusters) {
    G <- m[[k]]$G
    stats$G[k] <- G
    stats$loglik[k] <- round(m[[k]]$loglik,1)
    score[k] <- 2 * m[[k]]$loglik - G * log(n)  # This is the BIC equation

    stats$bic[k] <- round(score[k],1)
    
    # Penalize one-cluster cases according to the variance size
    if(G == 1)
      score[k] <- score[k] - 200

    # Penalize for interference, ie overlapping Gaussians
    interference_penalty <- abs(score[k]) * m[[k]]$interference 
    score[k] <- score[k] - interference_penalty
    stats$interference[k] <- round(interference_penalty,1)
    
    # Penalize for abnormal spacing
    spacing_penalty <- spacing_fail(m[[k]]$mean,m[[k]]$sigmasq)
    score[k] <- score[k] - spacing_penalty
    stats$spacing[k] <- round(spacing_penalty,1)

    stats$final[k] <- round(score[k],1)
  }
  if(verbose) print(stats)
  winner <- which(score == max(score))[1]

  if(verbose) spacing_model(m[[winner]]$mean,m[[winner]]$sigmasq)
  
  m[[winner]]
}

em_canary_no_prior <- function(x,fullprior,cnv_name=NULL,verbose=FALSE) {
  clusters <- selectmodel_noprior(x,verbose=verbose)
  variance <- list(d=1,G=clusters$G,sigmasq=clusters$sigmasq)
  parameters <- list(pro=clusters$prop,mean=clusters$mean,
                     variance=variance)
  model <- estep('V',x,parameters)
  z <- model$z       # the posterior probabilities
  assignments <- sapply(1:nrow(z),
                          function(i) which(z[i,]==max(z[i,])))
  confidences <- confidence_scores(x,parameters,z)
  results <- list(assignments = assignments,confidences = confidences,
                  clusters=clusters)
  if(graphing) hist_cnv(x,results,cnv_name,fullprior,'no prior')
  results
}

buildprior <- function(fullprior,n,cluster_vec) {
  pseudopoint_factor <- 100  # This number is inversely proportional to the
                            # number of pseudopoints in each cluster

  pro_labels <- paste('P',cluster_vec,sep='')
  mean_labels <- paste('M',cluster_vec,sep='')
  sigmasq_labels <- paste('V',cluster_vec,sep='')
  sigmasq <- as.numeric(fullprior[,sigmasq_labels])
  sigmasq[sigmasq < min_variance] <- min_variance
  prior <- list(G=length(cluster_vec),
  		cluster_vec=cluster_vec,
                pro=as.numeric(fullprior[,pro_labels]),
                mean=as.numeric(fullprior[,mean_labels]),
                sigmasq=sigmasq,
                num_pseudopoints=rep(max(0.5,n/pseudopoint_factor),
                  length(cluster_vec)))
  prior
}

hwe <- function(counts,cluster_vector) {
  if(identical(cluster_vector,c(0))) return(1)
  if(identical(cluster_vector,c(2))) return(1)
  if(identical(cluster_vector,c(4))) return(1)
  if(identical(cluster_vector,c(0,1)))
    return(hardyWeinberg_twoallele(c(counts,0)))
  if(identical(cluster_vector,c(1,2)))
    return(hardyWeinberg_twoallele(c(0,counts)))
  if(identical(cluster_vector,c(2,3)))
    return(hardyWeinberg_twoallele(c(counts,0)))
  if(identical(cluster_vector,c(3,4)))
    return(hardyWeinberg_twoallele(c(0,counts)))
  if(identical(cluster_vector,c(0,1,2)))
    return(hardyWeinberg_twoallele(counts))
  if(identical(cluster_vector,c(2,3,4)))
    return(hardyWeinberg_twoallele(counts))
  if(identical(cluster_vector,c(1,2,3)))
    return(hardyWeinberg_threeallele(c(0,counts,0)))
  if(identical(cluster_vector,c(0,1,2,3)))
    return(hardyWeinberg_threeallele(c(counts,0)))
  if(identical(cluster_vector,c(1,2,3,4)))
    return(hardyWeinberg_threeallele(c(0,counts)))
  if(identical(cluster_vector,c(0,1,2,3,4)))
    return(hardyWeinberg_threeallele(counts))
}

# Counts must have 3 elements
hardyWeinberg_twoallele <- function(counts) {
  aa <- counts[1]
  ab <- counts[2]
  bb <- counts[3]
  observed <- c(aa,ab,bb)
  freq_a = (2*aa+ab) / (2*sum(observed))
  freq_b = (2*bb+ab) / (2*sum(observed))
  expected <- c(freq_a*freq_a*sum(observed),
                2*freq_a*freq_b*sum(observed),
                freq_b*freq_b*sum(observed))
  chisq <- sum( (observed-expected)^2 / expected )
  #added for monomorphic CNVs
  if (is.na(chisq)) chisq=0
  pchisq(chisq, df=1, lower.tail=FALSE)
}

# Counts must have 5 elements
hardyWeinberg_threeallele <- function(counts) {
  copy0 <- counts[1]
  copy1 <- counts[2]
  copy2 <- counts[3]
  copy3 <- counts[4]
  copy4 <- counts[5]
  this_verbose <- TRUE
  observed <- c(copy0,copy1,copy2,copy3,copy4)
  total <- sum(observed)
  total_alleles <- 2 * sum(observed)
  freq0 <- (2*copy0 + copy1) / total_alleles
  freq2 <- (2*copy4 + copy3) / total_alleles
  freq1 <- 1 - freq0 - freq2
  expected0 <- total * freq0^2
  expected1 <- total * 2 * freq0 * freq1
  expected2 <- total * (freq1^2 + 2 * freq0 * freq2)
  expected3 <- total * 2 * freq2 * freq1
  expected4 <- total * freq2^2
  expected <- c(expected0,expected1,expected2,expected3,expected4)
  chisq <- sum((observed-expected)^2 / expected,na.rm=TRUE)
  if(this_verbose) {
    cat('Freqs: ',round(c(freq0,freq1,freq2),2),'\n')
    cat('Observed: ',round(observed,2),'\n')
    cat('Expected: ',round(expected,2),'\n')
    cat(total,sum(expected),'\n')
    cat('HWE Chisq: ',chisq,'\n')
  }
  # next line for monomorphic CNVs
  if (is.na(chisq)) chisq=0
  pchisq(chisq, df=2, lower.tail=FALSE)
}

assay_fit <- function(x,prior,fullprior,clustering,cluster_vector, params=NULL) {
  #print (params)
  af_weight<-params$af_weight
  hwe_weight<-params$hwe_weight
  closeness_weight<-params$closeness_weight
  overlap_weight<-params$overlap_weight
  globalpenalty_weight<-params$globalpenalty_weight
  bic_weight<-params$bic_weight

  tol <- 1e-3  # how close the priors and clusters can possibly be

  n <- length(x)
  G <- prior$G
  loglik <- clustering$loglik
  bic <- 2 * loglik - G * log(n)  # This is the BIC equation
  bic<-bic*bic_weight

  cat('Cluster vector:',cluster_vector,'\n')
  cat('Prior mean: ',prior$mean,'\n')
  cat('Clustering mean: ',clustering$mean,'\n')
  closeness <- abs(prior$mean - clustering$mean) / (0.5 + prior$mean)
  cat('Closeness: ',closeness,'\n')
  closeness[closeness < tol] <- tol

  # mean 1/closeness
  closeness_penalty <- closeness_weight * max(closeness)^2

  frequencies <- clustering$pro

  base_frequencies <- as.numeric(fullprior[,c('P0','P1','P2','P3','P4')])
  actual_frequencies <- dropin(max_clusters,cluster_vector,clustering$prop)
  actual_frequencies[is.na(actual_frequencies)] <- 0

  #old freq test
  cat('Base frequencies: ',base_frequencies,'\n')
  cat('Actual frequencies: ',actual_frequencies,'\n')
  delta_frequencies <- base_frequencies - actual_frequencies
  cat('AF delta:',delta_frequencies,'Total:',sum(delta_frequencies^2),'\n')
  #af_penalty <- af_weight * sum(delta_frequencies^2)
  delta_af_penalty<-af_weight * sum(delta_frequencies^2)

  #new improved likelihood frequency test
  freqTest<-alleleFreqTest(base_frequencies, actual_frequencies*length(x))
  cat ('frequency likelihood test', freqTest, '\n')
  #using new frequency likeliness test if the next line is uncommented.
  likelihood_af_penalty <-freqTest * af_weight
  cat ('Using freq likelihood test','\n')

  hwe <- hwe(n*frequencies,cluster_vector)
  hwe_penalty <- hwe_weight * (log10(hwe))^2
    
  overlap_penalty <- overlap_weight * interference_model(clustering$mean,
                                                         clustering$sigmasq)

  fit <- bic - globalpenalty_weight * (overlap_penalty + hwe_penalty + likelihood_af_penalty + closeness_penalty)
  
  round(c(loglik,bic,closeness_penalty,overlap_penalty,delta_af_penalty,likelihood_af_penalty,
          hwe_penalty,fit),1)
}

alleleFreqTest<-function (expected_freqs, observed_counts) {
  # Sample data
   observed_freqs <- observed_counts / sum(observed_counts)

   # So that nothing is considered impossible to observe:
   expected_freqs <- sapply( expected_freqs, function(x) max(x,1e-04) )
   observed_freqs <- sapply( observed_freqs, function(x) max(x,1e-04) )

   # Now calculate:
   max_log_lhood <- sum( log( observed_freqs ) * observed_counts )
   obs_log_lhood <- sum( log( expected_freqs ) * observed_counts )
   score <- (max_log_lhood - obs_log_lhood) / log(10)
   return (score)
}

selectmodel_withprior <- function(x,fullprior,verbose=verbose, params, outDir=NULL) {
  additionalModels<-F

  this_verbose <- FALSE
  n <- length(x)

  modelset <- list()
  model_names <- c()
  
  freqs <- as.numeric(fullprior[c('P0','P1','P2','P3','P4')])

  # Currently not testing for a 4 cluster alone.  If you want to add this
  # then you should penalize
  
  if(use_af) {
    if(sum(freqs[4:5]) == 0) {
      clustering_set <- list(c(0),c(2),c(0,1),c(1,2),c(0,1,2))
      scores <- data.frame(matrix(NA,nrow=length(clustering_set),ncol=7))
      row.names(scores) <- c('model0','model2','model01','model12','model012')
    } else if (sum(freqs[1:2]) == 0) {
      clustering_set <- list(c(2),c(2,3),c(3,4),c(2,3,4))
      scores <- data.frame(matrix(NA,nrow=length(clustering_set),ncol=7))
      row.names(scores) <- c('model2','model23','model34', 'model234')
    } else {
      clustering_set <- list(c(0),c(2),c(0,1),c(1,2),c(2,3),c(3,4),
                             c(0,1,2),c(2,3,4),c(1,2,3),c(0,1,2,3),c(1,2,3,4),
                             c(0,1,2,3,4))
      scores <- data.frame(matrix(NA,nrow=length(clustering_set),ncol=7))
      row.names(scores) <- c('model0','model2','model01','model12',
                             'model23','model34','model012','model234',
                             'model123','model0123','model1234','model01234')
    }
    
  } else {
    clustering_set <- list(c(0),c(2),c(0,1),c(1,2),c(2,3),c(3,4),
                           c(0,1,2),c(2,3,4),c(1,2,3),c(0,1,2,3),c(1,2,3,4),
                           c(0,1,2,3,4))
    scores <- data.frame(matrix(NA,nrow=length(clustering_set),ncol=8))
    row.names(scores) <- c('model0','model2','model01','model12',
                           'model23','model34','model012','model234',
                           'model123','model0123','model1234','model01234')
  }

  names(scores) <- c('loglik','bic','closeness','overlap','af','af_likelihood', 'hwe','fit')
 
  #remove this line to get rid of extra models
  if (additionalModels) {
     rownames(scores)<-paste(rownames(scores), 'f', sep='')
  } else { 
     rownames(scores)<-paste(rownames(scores), sep='')
  }

  for(cluster_vector in clustering_set) {
    #remove the 'f' to get rid of extra models.
    if (additionalModels) {
       cluster_label <- paste('model',paste(cluster_vector,  collapse=''),'f', sep='')
    } else {
       cluster_label <- paste('model',paste(cluster_vector,  collapse=''), sep='')
    } 
    model_names <- c(model_names,cluster_label)
    this_prior <- buildprior(fullprior,n,cluster_vector)
    this_clustering <- gmm_withprior(x,this_prior, params)
    this_fit <- assay_fit(x,this_prior,fullprior,this_clustering,
                          cluster_vector,params)
    modelset[[cluster_label]]$'cluster_vector'<- cluster_vector
    modelset[[cluster_label]]$'prior' <- this_prior
    modelset[[cluster_label]]$'clustering' <- this_clustering
    modelset[[cluster_label]]$'fit' <- this_fit
    scores[cluster_label,] <- this_fit
  }

  #this is a pretty goofy way to add extra models, so maybe there's a more elegant hack to be done.
  #remove this whole block to get rid of extra models.
  if (additionalModels) {
  
     for(cluster_vector in clustering_set) {
         cluster_label <- paste('model',paste(cluster_vector,collapse=''),'p', sep='')
         model_names <- c(model_names,cluster_label)
         this_prior <- buildprior(fullprior,n,cluster_vector)
         this_clustering <- gmm_withprior(x,this_prior, params, ratioDataUsed=0.95)
         this_fit <- assay_fit(x,this_prior,fullprior,this_clustering,
                               cluster_vector,params)
         modelset[[cluster_label]]$'cluster_vector'<- cluster_vector
         modelset[[cluster_label]]$'prior' <- this_prior
         modelset[[cluster_label]]$'clustering' <- this_clustering
         modelset[[cluster_label]]$'fit' <- this_fit
         scores[cluster_label,] <- this_fit
     }
  }

  print(scores)
  if (!is.null(outDir)) {
     z<-data.frame(cnv=rep(rownames(fullprior),dim(scores)[1]),
     model=rownames (scores), loglik=scores$loglik, bic=scores$bic,
     closeness=scores$closeness, af=scores$af, af_likelihood=scores$af_likelihood, hwe=scores$hwe, 
     fit=scores$fit)
     o<-paste (outDir,'/','models.txt', sep="")
     #disable model output.
     #write.table(z, o, append=T,row.names=F,col.names=F,quote=F, sep='\t')
  }
  winner <- which(scores[,'fit'] == max(scores[,'fit']))[1]
  #print(modelset[[winner]])
  modelset[[winner]]
}


geom_mean <- function(x) {
  exp(mean(log(as.numeric(x)),na.rm=TRUE))
}

div <- function(x) {
  sapply(2:length(x),function(i) x[i]/x[i-1])
}

powerlaw_coeff <- function(x) {
  d <- diff(x)
  if(length(x) < 3) {
    stop('Cannot compute the powerlaw coeff of a vector with < 3 elements!')
  } else {
    return(min(1,geom_mean(div(d))))
  }
}

# This next function creates a vector of length "size" and then drops in the
# vector "content" at the indices desired.  NOTE: The indices are zero based!
# Example: 
# > dropin(5,c(1,4),c(.7,.1))
# [1]  NA 0.7  NA  NA 0.1
dropin <- function(size,vec,contents) {
  if(max(vec) >= size) stop('Dropin index too large!')
  x <- rep(NA,size)
  x[vec+1] <- contents  # the +1 makes it zero-based
  x
}

fill_prop <- function(prop_vec,desired_length=5) {
  min_size <- 0.10
  pos_missing <- is.na(prop_vec)
  num_missing <- sum(pos_missing)
  pos_present <- !is.na(prop_vec)
  present <- prop_vec[pos_present]

  # This next part ensures that each of the existing components is > min_size
  original <- present
  present[present < min_size] <- min_size
  delta <- sum(present - original)
  present[which(present==max(present))] <-
    present[which(present==max(present))] - delta
  prop_vec <- dropin(desired_length,which(pos_present) - 1,present)

  # How much of the prop vector to give away to missing clusters
  if(num_missing==1) {
    fraction_giveaway <- 0.10
  } else if (num_missing==2) {
    fraction_giveaway <- 0.15
  } else if (num_missing==3) {
    fraction_giveaway <- 0.20
  } else if (num_missing==4) {
    fraction_giveaway <- 0.30
  } else {
    fraction_giveaway <- 0.20
  }
  divisor <- 1/(1-fraction_giveaway)
  total <- sum(prop_vec,na.rm=TRUE)
  new_prop <- prop_vec / divisor
  percluster_need <- fraction_giveaway / sum(is.na(prop_vec))
  new_prop[is.na(new_prop)] <- percluster_need
  new_prop
}

increment <- function(m1,m2,pow) {
  m2 + pow * (m2 - m1)
}

decrement <- function(m1,m2,pow) {
  m1 - (1/pow) * (m2 - m1)
}

impute_missing_clusters_priorinfo <- function(model,fullprior) {
  c0 <- 1                     # array index of the 0 copy-number cluster
  c1 <- 2                     # array index of the 1 copy-number cluster
  c2 <- 3                     # array index of the 2 copy-number cluster
  c3 <- 4                     # array index of the 3 copy-number cluster
  c4 <- 5                     # array index of the 4 copy-number cluster

  cluster_vector <- model$'cluster_vector'
  old_clustering <- model$'clustering'
  final_model = list()
  final_model$'prior' <- model$'prior'
  final_model$'preimputed_cluster_vector' <- model$'cluster_vector'
  final_model$'preimputed_clustering' <- model$'clustering'
  final_model$'cluster_vector' <- c(0,1,2,3,4)
  final_model$'fit' <- model$'fit'

  clustering <- list()
  clustering$prop <- dropin(max_clusters,cluster_vector,old_clustering$prop)
  clustering$mean <- dropin(max_clusters,cluster_vector,old_clustering$mean)
  clustering$sigmasq <- dropin(max_clusters,cluster_vector,
                               old_clustering$sigmasq)
  clustering$loglik <- model$'clustering'$loglik
  
  if(identical(cluster_vector,c(0,1,2,3,4))) {
    final_model$'clustering' <- model$clustering
    return(final_model)
  }

  if(identical(cluster_vector,c(0))) {
    this_power <- average_power
    
    clustering$mean[c1] <- clustering$mean[c0] + slope01
    clustering$mean[c2] <- increment(clustering$mean[c0],
                                     clustering$mean[c1],
                                     this_power)
    clustering$mean[c3] <- increment(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  
  if(identical(cluster_vector,c(2))) {
    this_power <- average_power
    clustering$mean[c1] <- clustering$mean[c2] - slope12
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c3] <- increment(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(4))) {
    this_power <- average_power
    clustering$mean[c3] <- clustering$mean[c4] - slope34
    clustering$mean[c2] <- decrement(clustering$mean[c3],
                                     clustering$mean[c4],
                                     this_power)
    clustering$mean[c1] <- decrement(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(0,1))) {
    this_power <- average_power
    clustering$mean[c2] <- increment(clustering$mean[c0],
                                     clustering$mean[c1],
                                     this_power)
    clustering$mean[c3] <- increment(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(1,2))) {
    this_power <- average_power
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c3] <- increment(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  
  if(identical(cluster_vector,c(2,3))) {
    this_power <- average_power
    clustering$mean[c1] <- decrement(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(3,4))) {
    this_power <- average_power
    clustering$mean[c2] <- decrement(clustering$mean[c3],
                                     clustering$mean[c4],
                                     this_power)
    clustering$mean[c1] <- decrement(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  
  if(identical(cluster_vector,c(0,1,2))) {
    this_power <- min(1,geom_mean(c(clustering$mean[c1]/clustering$mean[c0],
                                    clustering$mean[c2]/clustering$mean[c1])))
    
    clustering$mean[c3] <- increment(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    
    clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(2,3,4))) {
    this_power <- min(1,geom_mean(c(clustering$mean[c3]/clustering$mean[c2],
                                    clustering$mean[c4]/clustering$mean[c3])))
    
    clustering$mean[c1] <- decrement(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(1,2,3))) {
    this_power <- min(1,geom_mean(c(clustering$mean[c2]/clustering$mean[c1],
                                    clustering$mean[c3]/clustering$mean[c2])))
    
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(0,1,2,3))) {
    this_power <- min(1,geom_mean(c(clustering$mean[c1]/clustering$mean[c0],
                                    clustering$mean[c2]/clustering$mean[c1],
                                    clustering$mean[c3]/clustering$mean[c2])))
    
    clustering$mean[c4] <- increment(clustering$mean[c2],
                                     clustering$mean[c3],
                                     this_power)
    clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
  if(identical(cluster_vector,c(1,2,3,4))) {
    this_power <- min(1,geom_mean(c(clustering$mean[c4]/clustering$mean[c3],
                                    clustering$mean[c2]/clustering$mean[c1],
                                    clustering$mean[c3]/clustering$mean[c2])))
    
    clustering$mean[c0] <- decrement(clustering$mean[c1],
                                     clustering$mean[c2],
                                     this_power)
    clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
    clustering$prop <- fill_prop(clustering$prop)
    final_model$'clustering' <- clustering
    return(final_model)
  }
}

directional_impute <- function(model,fullprior) {
  c0 <- 1                     # array index of the 0 copy-number cluster
  c1 <- 2                     # array index of the 1 copy-number cluster
  c2 <- 3                     # array index of the 2 copy-number cluster
  c3 <- 4                     # array index of the 3 copy-number cluster
  c4 <- 5                     # array index of the 4 copy-number cluster

  cluster_vector <- model$'cluster_vector'
  old_clustering <- model$'clustering'
  final_model = list()
  final_model$'prior' <- model$'prior'
  final_model$'preimputed_cluster_vector' <- model$'cluster_vector'
  final_model$'preimputed_clustering' <- model$'clustering'
  final_model$'fit' <- model$'fit'
  
  freqs <- as.numeric(fullprior[c('P0','P1','P2','P3','P4')])

  if(sum(freqs[4:5]) == 0) {  # The 0,1,2 case
    final_model$'cluster_vector' <- c(0,1,2)
    clustering <- list()
    clustering$prop <- dropin(3,cluster_vector,old_clustering$prop)
    clustering$mean <- dropin(3,cluster_vector,old_clustering$mean)
    clustering$sigmasq <- dropin(3,cluster_vector,old_clustering$sigmasq)
    clustering$loglik <- model$'clustering'$loglik

    if(identical(cluster_vector,c(0,1,2))) {
      final_model$'clustering' <- model$clustering
      return(final_model)
    }

    if(identical(cluster_vector,c(0))) {
      this_power <- average_power
      
      clustering$mean[c1] <- clustering$mean[c0] + slope01
      clustering$mean[c2] <- increment(clustering$mean[c0],
                                       clustering$mean[c1],
                                       this_power)

      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(2))) {
      this_power <- average_power

      clustering$mean[c1] <- clustering$mean[c2] - slope12
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(0,1))) {
      this_power <- average_power

      clustering$mean[c2] <- increment(clustering$mean[c0],
                                       clustering$mean[c1],
                                       this_power)

      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(1,2))) {
      this_power <- average_power
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- clustering
      return(final_model)
    }
  } else if (sum(freqs[1:2]) == 0) {   # the 2,3,4 case
    final_model$'cluster_vector' <- c(2,3,4)
    clustering <- list()
    clustering$prop <- dropin(3,cluster_vector - 2,
                              old_clustering$prop)
    clustering$mean <- dropin(max_clusters,cluster_vector,
                              old_clustering$mean)
    clustering$sigmasq <- dropin(max_clusters,cluster_vector,
                                 old_clustering$sigmasq)
    clustering$loglik <- model$'clustering'$loglik

    trim <- function(clust) {
      newclust <- list()
      newclust$mean <- (clust$mean)[3:5]
      newclust$sigmasq <- (clust$sigmasq)[3:5]
      newclust$prop <- clust$prop
      newclust$loglik <- clust$loglik
      newclust
    }
    
    if(identical(cluster_vector,c(2,3,4))) {
      final_model$'clustering' <- trim(clustering)
      return(final_model)
    }
    if(identical(cluster_vector,c(2))) {
      this_power <- average_power

      clustering$mean[c3] <- clustering$mean[c2] + slope23
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- trim(clustering)
      return(final_model)
    }
    if(identical(cluster_vector,c(4))) {
      this_power <- average_power
      clustering$mean[c3] <- clustering$mean[c4] - slope34
      clustering$mean[c2] <- decrement(clustering$mean[c3],
                                       clustering$mean[c4],
                                       this_power)
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- trim(clustering)
      return(final_model)
    }
    if(identical(cluster_vector,c(2,3))) {
      this_power <- average_power
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- trim(clustering)
      return(final_model)
    }
    if(identical(cluster_vector,c(3,4))) {
      this_power <- average_power
      clustering$mean[c2] <- decrement(clustering$mean[c3],
                                       clustering$mean[c4],
                                       this_power)

      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$prop <- fill_prop(clustering$prop,desired_length=3)
      final_model$'clustering' <- trim(clustering)
      return(final_model)
    }
  } else {
    final_model$'cluster_vector' <- c(0,1,2,3,4)
    clustering <- list()
    clustering$prop <- dropin(max_clusters,cluster_vector,old_clustering$prop)
    clustering$mean <- dropin(max_clusters,cluster_vector,old_clustering$mean)
    clustering$sigmasq <- dropin(max_clusters,cluster_vector,
                                 old_clustering$sigmasq)
    clustering$loglik <- model$'clustering'$loglik
  
    if(identical(cluster_vector,c(0,1,2,3,4))) {
      final_model$'clustering' <- model$clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(0))) {
      this_power <- average_power

      clustering$mean[c1] <- clustering$mean[c0] + slope01
      clustering$mean[c2] <- increment(clustering$mean[c0],
                                       clustering$mean[c1],
                                       this_power)
      clustering$mean[c3] <- increment(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(2))) {
      this_power <- average_power
      clustering$mean[c1] <- clustering$mean[c2] - slope12
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c3] <- increment(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(4))) {
      this_power <- average_power
      clustering$mean[c3] <- clustering$mean[c4] - slope34
      clustering$mean[c2] <- decrement(clustering$mean[c3],
                                       clustering$mean[c4],
                                       this_power)
      clustering$mean[c1] <- decrement(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(0,1))) {
      this_power <- average_power
      clustering$mean[c2] <- increment(clustering$mean[c0],
                                       clustering$mean[c1],
                                       this_power)
      clustering$mean[c3] <- increment(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(1,2))) {
      this_power <- average_power
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c3] <- increment(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    
    if(identical(cluster_vector,c(2,3))) {
      this_power <- average_power
      clustering$mean[c1] <- decrement(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(3,4))) {
      this_power <- average_power
      clustering$mean[c2] <- decrement(clustering$mean[c3],
                                       clustering$mean[c4],
                                       this_power)
      clustering$mean[c1] <- decrement(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$sigmasq[c2] <- as.numeric(fullprior['V2'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    
    if(identical(cluster_vector,c(0,1,2))) {
      this_power <- min(1,geom_mean(c(clustering$mean[c1]/clustering$mean[c0],
                                      clustering$mean[c2]/clustering$mean[c1])))

      clustering$mean[c3] <- increment(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)

      clustering$sigmasq[c3] <- as.numeric(fullprior['V3'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(2,3,4))) {
      this_power <- min(1,geom_mean(c(clustering$mean[c3]/clustering$mean[c2],
                                    clustering$mean[c4]/clustering$mean[c3])))
      
      clustering$mean[c1] <- decrement(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c1] <- as.numeric(fullprior['V1'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(1,2,3))) {
      this_power <- min(1,geom_mean(c(clustering$mean[c2]/clustering$mean[c1],
                                      clustering$mean[c3]/clustering$mean[c2])))

      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$mean[c0] <- decrement(clustering$mean[c1],
                                       clustering$mean[c2],
                                       this_power)
      clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
    if(identical(cluster_vector,c(0,1,2,3))) {
      this_power <- min(1,geom_mean(c(clustering$mean[c1]/clustering$mean[c0],
                                      clustering$mean[c2]/clustering$mean[c1],
                                      clustering$mean[c3]/clustering$mean[c2])))

      clustering$mean[c4] <- increment(clustering$mean[c2],
                                       clustering$mean[c3],
                                       this_power)
      clustering$sigmasq[c4] <- as.numeric(fullprior['V4'])
      clustering$prop <- fill_prop(clustering$prop)
      final_model$'clustering' <- clustering
      return(final_model)
    }
     if(identical(cluster_vector,c(1,2,3,4))) {
       this_power <- min(1,geom_mean(c(clustering$mean[c4]/clustering$mean[c3],
                         clustering$mean[c2]/clustering$mean[c1],
                         clustering$mean[c3]/clustering$mean[c2])))

       clustering$mean[c0] <- decrement(clustering$mean[c1],
                                        clustering$mean[c2],
                                        this_power)
       clustering$sigmasq[c0] <- as.numeric(fullprior['V0'])
       
       clustering$prop <- fill_prop(clustering$prop)
       final_model$'clustering' <- clustering
       return(final_model)
    }
  }
}


# params is a list of tunable parameters for canary:
# af_weight <- 100 # how much to use allele freq
# hwe_weight <- 10 # how much to use hwe
# closeness_weight <- 100
# overlap_weight <- 500
# globalpenalty_weight <- 0.3
# pseudopointFactor<-1 #scaling factor for how pseudo points are used
# simplePriorScaling <-F #should priors be scaled via simple method?
# if a parameter isn't set, it goes to the default value above.

em_canary_with_prior <- function(x,fullprior,cnv_name=NULL,verbose=FALSE, outDir=NULL, params=NULL) {
  #hack for BV, gets scan names in here for output of membership scores. 
  indivNames=names(x)
  x<-as.numeric(x)

  params<-initializeParams(params)
  if (use_af) cat ('Using directional priors!', '\n')

  fullprior=simpleSHIFTPriors(fullprior, x, params$simplePriorScaling, outDir)
  
  winning_model <- selectmodel_withprior(x,fullprior,verbose=verbose, params, outDir=outDir)
  additionalImputation<-T
  if (additionalImputation) {
     if(use_af) {
       cat ('Using additional directional imputation','\n') 
       final_model <- directional_impute(winning_model,fullprior)
     } else {    
       cat ('Using NEW additional imputation without direction', '\n')
       final_model <- impute_missing_clusters_priorinfo2(winning_model,fullprior)
     }
     final_model$clustering$sigmasq <-regularize_variances(final_model$clustering$sigmasq)
     #print(final_model)
     winning_model <- final_model
  } else {
     cat ('Not using additional imputation of any kind', '\n')
  }
  
  clusters <- winning_model$clustering
  labels <- winning_model$cluster_vector
  G <- length(clusters$mean)
  variance <- list(d=1,G=G,sigmasq=clusters$sigmasq)
  parameters <- list(pro=clusters$prop,mean=clusters$mean,
                     variance=variance)
  model <- estep('V',x,parameters)
  z <- model$z       # the posterior probabilities

  
  z<-breakProbabilityTies(z)

  #hack for BV to output cluster membership for dosage type effects.
  outputFinalClusterMembership(z, rownames (fullprior)[1], indivNames, outDir)

  prelimassignments <- sapply(1:nrow(z),
                              function(i) which(z[i,]==max(z[i,])))
 
  assignments <- labels[prelimassignments]
  confidences <- confidence_scores(x,parameters,z)
  #HACKTASTIC
  #change a cluster that's entirely 2 to have decent confidence scores instead of NA
  if (additionalImputation==F & all(is.na(confidences))) confidences<-rep(1e-4, length(confidences))    
  
  results <- list(assignments = assignments,confidences = confidences,
                  clusters=clusters)
  if(graphing) hist_cnv(x,results,cnv_name,fullprior,
                        paste('with prior','(fit',
                              toString(winning_model$preimputed_cluster_vector),
                              ')'))
  results
}

outputFinalClusterMembership<-function (z, cnpName, indivNames, outDir=NULL) {
   if (is.null(outDir)) return (NULL)
   zz<-cbind (cnpName, indivNames, z)
   colnames (zz)[2:7]=c('individual', paste ("CN", seq(0,4), sep=""))
   write.table(zz, file=paste (outDir, "/cluster_membership.txt", sep=""), append=T, sep="\t", col.names=F, row.names=F, quote=F)
}


breakProbabilityTies<-function (z) {
   #break ties in the probabilities
   #kinda a complete hack
   #find the best probability for the sample on this CNV
   maxProbIdx<-apply (z, 1, function (x) {which(max(x)==x) } )
   #find the most common class out of the options available - should this call be a 4 or 5, for example.
   findModeLabel<-function (maxProbIdx, idx) {
       q3<-sapply (idx, function (x) { length 
             (which (unlist (maxProbIdx)==x))})
       idx[min (which (q3==max(q3)))]     
   }

   for (i in 1:length(maxProbIdx)) {
       idx<-maxProbIdx[[i]]     
       if (length(idx)>1) {
         #breaking a tie.
    	 cat ('Breaking probability tie','\n')
	 best<-findModeLabel(maxProbIdx, idx)
	 z[i,best]<-z[i,best]*1.01
       }
   }
   return (z)
}

#sets defaults for parameters that are not yet filled in
#this guarantees that there is some reasonable default value for every parameter needed.
initializeParams<-function (params) {
  if (is.null(params)) params<-list() 
  
  if (!any(names(params)=="af_weight")) params$af_weight<-8
  if (!any(names(params)=="hwe_weight")) params$hwe_weight<-10
  if (!any(names(params)=="closeness_weight")) params$closeness_weight<-100
  if (!any(names(params)=="overlap_weight")) params$overlap_weight<-500
  if (!any(names(params)=="globalpenalty_weight")) params$globalpenalty_weight<-0.3
  if (!any(names(params)=="pseudopointFactor")) params$pseudopointFactor<-1
  if (!any(names(params)=="simplePriorScaling")) params$simplePriorScaling<-F
  if (!any(names(params)=="robust_means")) params$robust_means<-F  
  if (!any(names(params)=="constrain_variance")) params$constrain_variance=0
  if (!any(names(params)=="bic_weight")) params$bic_weight<-1
  print (params)
  if (params$constrain_variance==0) cat ('Constrain variance off!', '\n')
  return (params)
}

#calculates the scaling factor for priors, but doesn't change priors unless active is true.
simpleScalePriors<-function (fullprior, x, active=F, outDir) {
   if (active) { 
      cat ('Simple Scale Priors Active','\n')
      cat ('Before', '\n')
      print (fullprior) 
   }

   meanIdx<-6:10
   varIdx<-11:15
   freqIdx<-1:5
   expectedMean<-weighted.mean(fullprior[meanIdx], fullprior[freqIdx])
   observedMean<-mean (x)
   scaleFactor<-observedMean/expectedMean
   if (active) {
      fullprior[meanIdx]<-fullprior[meanIdx]*scaleFactor
      fullprior[varIdx]<-fullprior[varIdx]*(scaleFactor^2)
      cat ('After','\n')
      print  (fullprior)
   }
   outFile<-paste (outDir, "scaleFactor.txt", sep="/")
   if (!is.null(outDir)) write(c(rownames (fullprior), scaleFactor), outFile, append=T, ncolumns=2, sep="\t")
   return (fullprior)
}


simpleSHIFTPriors<-function (fullprior, x, active=F, outDir) {
   if (active) {
      cat ('Simple Shift Priors Active','\n')
      cat ('Before', '\n')
      print (fullprior)
   }

   meanIdx<-6:10
   varIdx<-11:15
   freqIdx<-1:5
   expectedMean<-weighted.mean(fullprior[meanIdx], fullprior[freqIdx])
   observedMean<-mean (x)
   shiftFactor<-observedMean - expectedMean
   if (active) {
      fullprior[meanIdx]<-fullprior[meanIdx] + shiftFactor
      cat ('After','\n')
      print  (fullprior)
   }
   outFile<-paste (outDir, "shiftFactor.txt", sep="/")
   if (!is.null(outDir)) write(c(rownames (fullprior), shiftFactor), outFile, append=T, ncolumns=2, sep="\t")
   return (fullprior)
}

impute_missing_clusters_priorinfo2<-function (winning_model, fullprior, thresholdForPrediction=0.05) {
   #what are the means?
   obsMeans<-rep(NA, 5)
   #for any portion of the model that is represented by less than some threshold % of data, NA it.
   idxToRemove<-which(winning_model$clustering$prop<thresholdForPrediction)
   if (length(idxToRemove>0)) {
      winning_model$clustering$mean[idxToRemove]<-NA
      winning_model$clustering$prop[idxToRemove]<-NA
      winning_model$clustering$sigmasq[idxToRemove]<-NA
   }
   obsMeans[(winning_model$prior$cluster_vec)+1]<-winning_model$clustering$mean
   idxMissing<-which (is.na(obsMeans))
   weights=as.numeric (fullprior[1:5])

   priorMeans<-as.numeric (fullprior[6:10])
   #z<-lm(obsMeans ~ priorMeans)
   z<-lm (obsMeans ~ priorMeans, weights=weights)

   intercept<-z[[1]][1]
   slope<-z[[1]][2]

   #Hack.  If you can't rely on the priors frequency weight, don't use it.
   if (is.na(slope) && is.na(intercept)) {
     z<-lm(obsMeans ~ priorMeans)
     intercept<-z[[1]][1]
     slope<-z[[1]][2]
     cat (rownames (fullprior), 'priors do not well match the data observed.', '\n')
   }

   #if there's a slope, use that to scale the priors.
   if (!is.na(slope)) {
      newMeans<-(priorMeans*slope)+intercept
   } else { #technical artifact of lm needing multiple points to generate a slope.
      #IN CASES WHERE THE PRIOR AND THE OBSERVED CLASSES DIFFER
      #AND THE OBSERVED DATA HAS CLASSES WHERE THE PRIOR HAS 0% CHANCE OF THAT CLASS
      #JUST USE THE FIRST NON-ZERO WEIGHT.
      #simple scaling of means when there's 1 cluster
      idxAvail=which(!is.na(obsMeans))
      if (length(idxAvail)>1) {
         idxAvail=which (weights==max(weights[idxAvail]))
      }
      ratio=obsMeans[idxAvail]/priorMeans[idxAvail]
      newMeans<-priorMeans*ratio
   }

   obsMeans[idxMissing]<-newMeans[idxMissing]

   obsSD<-rep(NA, 5)
   obsSD[(winning_model$prior$cluster_vec)+1]<-sqrt(winning_model$clustering$sigmasq)

   priorSD<-sqrt(as.numeric(fullprior[11:15]))
  
   z<-lm(obsSD ~ priorSD)
   slope<-z[[1]][2]
   
   #Hack.  If you can't rely on the priors frequency weight, don't use it.
   if (is.na(slope) && is.na(intercept)) {
       z<-lm(obsSD ~ priorSD)
       slope<-z[[1]][2]
   }
   #if there's a slope, use that to scale priors.
   if (!is.na(slope)) {
      newSD<-(priorSD*slope) 
   } else { #technical artifact of lm needing multiple points to generate a slope.
       #simple scaling of variance when there's 1 cluster
       idxAvail=which(!is.na(obsSD)) 

       #if there are multiple points, get the highest weighted prior with data.
       if (length(idxAvail)>1) {
         idxAvail= which (weights==max(weights[idxAvail])) 
       }
       ratio=obsSD[idxAvail]/priorSD[idxAvail]
       newSD<-priorSD*ratio
   }

   obsSD[idxMissing]<-newSD[idxMissing]

   newProp<-rep(NA, 5)
   newProp[(winning_model$prior$cluster_vec)+1]<-winning_model$clustering$prop
   newProp<-fill_prop(newProp)
   
   winning_model$clustering$mean<-obsMeans
   winning_model$clustering$sigmasq<-obsSD^2
   
   winning_model$clustering$prop <- newProp
   winning_model$cluster_vector<-c(0,1,2,3,4)
   return (winning_model)
}
