# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright 2008 by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

#A HANDY UTILITY FUNCTION TO GET COMMAND LINE ARGS
#IF A ARG IS REQUESTED THAT IS NOT SET, AND HAS NO DEFAULT, QUIT THE R SCRIPT.
#OTHERWISE, USE THE SET ARG, AND FALL BACK TO THE DEFAULT
# example from command line: R CMD BATCH --profile=test --profileMap=test2 CNP_Probe_Selection_Client.R
#passes two arguments to the script CNP_Probe_Selection_Client.R

commandLineArg <- function(arg_name, default=NA, verbose=F) {
	look_for_text <- paste( "--", arg_name, "=", sep="" )
    arg_id <- which( substring( commandArgs(), 1, nchar(look_for_text) ) == look_for_text )
    #Argument is not found, default is null (special case)
    if (length(arg_id)==0 && is.null(default)) return (default)
    #Argument is not found, and no default is set.  Quit.
    if (length(arg_id)==0 && !is.null(default) && is.na(default)) {
    	print (paste ('Arg not found:', arg_name, sep=" "))
        print (paste ('No default set, quitting'))
        q("no")
    }
    if (length(arg_id)==0 && !is.na(default)) {
    	print (paste ("Arg not found: ", arg_name, sep=""))
	 	print (paste ("Using default [", default, "]", sep=""))
	 	return (default)
    }
      result<-substring( commandArgs()[arg_id[1]], nchar(look_for_text)+1, nchar(commandArgs()[arg_id[1]]) )
      if (verbose) print (paste ("Argument[", arg_name, "] value [", result, "]", sep=""))
      return (result)
}
   
#parse a delimited list of values for a parameter to a vector result. 
utils.commandLineArgList<-function (arg_name, default=NA, delimiter=",", verbose=F) {
	r1<-commandLineArg(arg_name, default, verbose)
	if (is.null(r1)) return (NULL)
	if (is.na(r1)) return (NA)
	strsplit (r1, delimiter)[[1]]
}


#takes a text vector and returns a seperated list.
utils.mergeText<- function (textvector, base, sep=",") {
   		if (length (textvector)==1) return (textvector)
   		base<-c(textvector[1])
   		for (i in 2:length(textvector)) base<-paste (base, textvector[i], sep=sep)
   		return (base)
}



utils.getDFForFilesOfType<-function (directory, fileHint, includeEmptyFiles=F, verbose=F, ...) {
	#fileHint is a substring that occurs in the files to look for.
	#if the file is empty, don't include it.
	#additional arguments are passed to read.talbe
	filesFull<-list.files(path=directory, full.names =T )
	files<-list.files(path=directory, full.names=F)
	idx<-grep (fileHint, files)
	if (length(idx)==0) return (NULL)
	filesFull<-filesFull[idx]
	files<-files[idx]
	result<-list()

	for (i in 1:length(files)) {
	   fname=files[i]
	   if (verbose) print (fname)
	   if (file.info(filesFull[i])$size>0) {
	      a<-read.table(filesFull[i], ...)
	      if (dim(a)[1]>0 | includeEmptyFiles) result[[fname]]<-a
	   }
	}
	return (result)
}

utils.flattenDFForFilesOfType<-function (DFList) {
	#take a list of data frames of the same type, and flatten them into a single data frame.
	#Handy to use in conjunction with utils.getDFForFilesOfType
	if (length(DFList)==0) return (NULL)
	if (length(DFList)==1) return (DFList[[1]])
	result<-DFList[[1]]
        for (i in 2:length(DFList)) result<-rbind (result, DFList[[i]])
	return (result)
}

