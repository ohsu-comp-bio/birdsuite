#intensityDataFile<-"data/MERGED.probeset_summary"
#assignmentDataFile<-"data/MERGED.canary_calls"
#uncertaintyFile<-"data/MERGED.canary_confs"
#mapFile<-"data/Hapmap2.plateMap"
#smartProbeFile=NULL
#rawAssignmentDataFile=NULL
#outDir="."
#plateMatchLabel="cel"
#priorsFile="data/GenomeWideSNP_6.canary_priors"
#plateMetaData=NULL

#smartProbeFile<-"6.0_plus_JK_smartProbes.txt"
# smartProbeFile<-"6.0_Map_smart_probes_merged.txt"
# outDir="Broad6_Result"
# outDir="Affy_6.0_JK_HapMap_Pooled"
# plateMetaData<-list(uncertainty="Broad6_Result/metaData_uncertainty.txt", chiTestScore="Broad6_Result/metaData_chiTestScore.txt")
# thresholdList<-list(uncertaintyThreshold=0.9)


#This function graphs all the CNPs in a set of matrix data files.  All matrixes have a column called "cnp_id" that has the cnp ID, and all other columns are sample names.  Each row is the data for one CNP.
#Required are:
#1)intensity - the raw intensities for the CNPs
#2)assignment - the assignments for that CNP (either cluster assignemnt or copy number)
#3)rawAssignment - the assignments prior to filtering that might have occurred - use this if you want to graph plates that did not pass QC checks.
#4)mapFile - maps the sample names to the plate the data came from, so you can determine which plate you are looking at.
#5)smartProbeFile - the information about how many smart probes are contained in a CNP, as well as it's location
#6)plateMetaData - a list of data matrix files.  Each matrix has a "cnp_id" column, followed by a column for each plate(plate must match mapFile plate name!).  Each of these matrixes is some sort of information about the plate, and is graphed below the assignment/intensity graph.  This meta data is graphed in the order it is given in the list, and the legend will show the name given in the list.
#7) The thresholdlist will graph ablines for the meta data.  Each name in the list is in the legend, and the value is plotted as a horizontal line in the meta data graph.
# PlateMatchLabel can be "sample" or "cel" to match the column of the plateMap file.
#priors file will draw the priors with 3 std devations.  
cnp_graphs.graphPlateClusterAssignments <- function (intensityDataFile, assignmentDataFile, uncertaintyFile, smartProbeFile=NULL, rawAssignmentDataFile=NULL, mapFile=NULL, outputFileName="clusterAssignmentOverlap.pdf", plateMetaData=NULL, thresholdList=NULL, plateMatchLabel="cel", priorsFile=NULL) {
    print ("Version 1.1")	
    map<-cnp_io.read_map(mapFile)
    #remove any nulls rom plateMetaData list.
   	if (!is.null (plateMetaData))plateMetaData <-plateMetaData[which (sapply (plateMetaData, function (x) !is.null(x)))]
		
	#read in data
	intensityDF<-cnp_io.readCNPAttribute2(intensityDataFile)
	#no longer needed as all input files have the same labels.  YAY.
	#rownames (intensityDF)<-paste ("CNV", rownames (intensityDF), sep="")
	assignmentDF<-cnp_io.readCNPAttribute2(assignmentDataFile)
	uncertaintyDF <-cnp_io.readCNPAttribute2(uncertaintyFile)
	
	if (is.null(rawAssignmentDataFile)) assignmentRawDF <-NULL else assignmentRawDF <- cnp_io.readCNPAttribute(rawAssignmentDataFile)
	if (is.null(smartProbeFile)) smartProbeDF<-NULL else smartProbeDF<-read.table(smartProbeFile, as.is=T, header=T)
	if (!is.null(priorsFile)) priors<-read.table(priorsFile, header=T) else priors<-NULL

	cnpsToGraph<-as.character (rownames(intensityDF))
	
	cnpsToGraph<-as.character(cnpUtils.sortCNPListNames(cnpsToGraph))

	#read in plate meta data
	if (!is.null(plateMetaData))plateMD<-cnp_io.readPlateMetaData(plateMetaData) else plateMD<-NULL
	
	pdf(outputFileName, width=12, height=12, version="1.5")
	z<-sapply (cnpsToGraph, cnp_graphs.graphPlateClusterAssignmentsOneCNP, intensityDF, assignmentDF, uncertaintyDF, map, assignmentRawDF, 
				smartProbeDF, plateMD, thresholdList, plateMatchLabel, priors)
	
	dev.off()
}


#metaData is a list of data frames.  Each data frame is one piece of meta data, with 1 row per CNP, each column is a plate name.  
cnp_graphs.graphPlateClusterAssignmentsOneCNP <- function (cnpName, intensityDF, assignmentDF, uncertaintyDF, map, assignmentRawDF=NULL, smartProbeDF, plateMD =NULL, thresholdList=NULL, plateMatchLabel="cel", priors=NULL, uncertaintyThreshold=0.1) {
	def.par <- par(no.readonly = TRUE)
	if (!is.null(plateMD)) layout(matrix(c(1,1,2,2), 2, 2, byrow = TRUE), heights=c(2.5,1))
	
	par(mar=c(5,4,8.5,2)+0.1)
	cat(paste("Graphing cluster assignments for CNP", cnpName, '\n', sep=" "))
	
	plateNames<-as.character (sort (unique (map$plate)))
	
	staggerPct=0.3
	intensity<-cnpUtils.getOneCNPLineByPlate(intensityDF[cnpName,], map, matchLabel= plateMatchLabel)
	assignment<-cnpUtils.getOneCNPLineByPlate(assignmentDF[cnpName,], map, matchLabel= plateMatchLabel)
	uncertainty<-cnpUtils.getOneCNPLineByPlate(uncertaintyDF[cnpName,], map, matchLabel= plateMatchLabel)
	
	if (is.null (assignmentRawDF)) rawAssign<-NULL else rawAssign<-cnpUtils.getCNPDataByPlate(assignmentRawDF, cnpName, map)
	
	maxIntensity<-max (unlist(intensity))
				
	if (is.null(rawAssign)) allAssignments<-unique (unlist (assignment)) else allAssignments<-unique(unlist(rawAssign))
	allAssignments<-sort (allAssignments[!is.na(allAssignments)])
	colList<-c(1,2,5,7,9,11)
	colors=rainbow(12)[colList]
	failedColors<-rainbow(12, s=0.5)[colList]
	
	plotIntensitiesForPlate<-function (plateIdx, plateNames, intensity, assignment, uncertainty, rawAssign) {
		plateName<-plateNames[plateIdx]
		goodDataFlag<-T
		proceed<-F
		
		if (length (which (names (assignment)==plateName)) > 0 && length (which (!is.na(assignment [[which (names (assignment)==plateName)]])))>0 ) {
			currentAssignments<-as.numeric (assignment[[plateName]])
			proceed<-T
		} else if (!is.null(rawAssign) && length (which (names (rawAssign)==plateName)) > 0) {
			currentAssignments<-as.numeric (rawAssign[[plateName]])
			goodDataFlag<-F
			proceed<-T
			# add path to graph cnps that have all NA assignments.
		} else {
			proceed<-F
			if (!is.null(intensity[[plateName]])) {
				intensities<-as.numeric (intensity[[plateName]])
				len<-length (intensities)
				points (plateIdx+0.3*(1:len)/len, intensities, col="grey", pch=21)
			}
		}
		 
		if (proceed) {
	 		assignments<-sort(unique(currentAssignments))
	 		intensities<-as.numeric (intensity[[plateName]])
	 		u<-as.numeric (uncertainty[[plateName]])
	 		if (length(intensities)!=length(currentAssignments)) print ("There are different numbers of intensities and assignments.  This is BAD")
	 		for (a in assignments) {
	 			#graph good data.
	 			idx<-which (currentAssignments ==a & u<= uncertaintyThreshold)
	 			if (length(idx)>0) {
	 				intensitiesForAssignment<-intensities[idx]
	 				len<-length (intensitiesForAssignment)
	 				if (goodDataFlag==T) plotchar=19 else plotchar=21
	 				color=colors[a+1] # the lowest assignemt is 0, lowest color index is 1.
	 				points (plateIdx+0.3*(1:len)/len, intensitiesForAssignment, col=color, pch=plotchar)
	 			}
	 			#graph NAs
	 			idx<-which (currentAssignments ==a & u>= uncertaintyThreshold)
	 			if (length (idx>0)) {
					intensitiesForAssignment<-intensities[idx]
	 				len<-length (intensitiesForAssignment)
	 				if (goodDataFlag==T) plotchar=19 else plotchar=21
	 				#color= colors[a+1] # the lowest assignemt is 0, lowest color index is 1.
	 				color=failedColors[a+1] # the lowest assignemt is 0, lowest color index is 1.
	 				points (plateIdx+0.3*(1:len)/len, intensitiesForAssignment, col=color, pch=21)
	 			}
	 			
	 		}
	 	}
	 	
	}
	plot (c(1,length(plateNames)+staggerPct), c(0, maxIntensity+.2), col="white", xlab="plate", ylab="intensity")
	
	z<-sapply (seq(1,length(plateNames)), plotIntensitiesForPlate, plateNames, intensity, assignment, uncertainty, rawAssign)
	
	legend("topright", paste("Cluster Assignment", allAssignments), fill=colors[allAssignments+1])
	legend("bottomright", paste (seq(1, length(plateNames)), plateNames ))
	
	titleInfo<-c("CNP ", cnpName)
	
	#this is a hack because CNV names are "CNV1" in the cluster pipeline and 
	#just "1" in the smart probe file.  This may get changed later!
	if (!is.null(smartProbeDF)) {
	   probes<-smartProbeDF[smartProbeDF$wh==substr(cnpName, 4, nchar(cnpName)),]
	   if (dim(probes)[1]==0) {
		print (paste ("CNP", cnpName, "Not found in smart probes given!"))
	   } else {
		chr<- min (probes$chr)
		pos=as.double(round(min (probes$pos)/ 1e6, 3))
		numProbes<-dim(probes)[1]
		titleInfo<-c(titleInfo, " #probes [", numProbes, "]\nchr [", chr, "] pos [", pos, "]") 
	   }
        }
	
	titleLine<-utils.mergeText(titleInfo, c(), sep="")
	title (titleLine)
	
	if (!is.null(plateMD)) {
		par(mar=c(3,4,3,5.2)+0.1)
		dataTypes<-names(plateMD)
		getData<-function (dataType, plateMD) {
			data<-plateMD[[dataType]]
			line<-data[data$cnp_id==cnpName,]
			d2<-line[match (plateNames, names(line))]
			#change NA's to 0.
			d2[is.na(d2)]<-0
			return (d2)
		}
		
		dataToPlot<-sapply (dataTypes, getData, plateMD)
			
		dataToPlot<-t(matrix (unlist (dataToPlot), nrow=length(plateNames)))
		
		barColors<-grey(seq(0.2,0.8, .6/(length(dataTypes)-1)))
		barplot(dataToPlot, beside=T, names.arg=(seq(1,dim(dataToPlot)[2])), col= barColors, border=grey(1), ylim=c(0,1.3))
		title("Plate Statistics")
		if (!is.null(thresholdList)) {
			for (i in 1:length (thresholdList)) {
				name<-names(thresholdList)[i]
				value<-thresholdList[[i]]
				abline(a=value, b=0, lty=2, col=colors[i])
				barColors<-c(barColors, colors[i])
				dataTypes<-c(dataTypes, name)
			}
			legend("topright", dataTypes, fill= barColors, inset=0.00, cex=1.0, ncol=2)
		}
		else {
			legend("topright", dataTypes, fill= barColors, inset=0.00, cex=1.0, )
		}
	}
	graphPriors(cnpName, priors, colors)
}

graphPriors<-function (cnpName, priors, colors, numSTD=2) {
	#if you can't find priors, don't graph 'em.
	if (!any(rownames(priors)==cnpName)) return (NULL)
	p<-priors[cnpName,]
	
	for (i in 0:4) {
		mName<-paste ("M", i, sep="")
		vName<-paste ("V", i, sep="")	
		mean<-p[[mName]]
		std<-sqrt(p[[vName]])
		low<-mean-(numSTD*std)
		high<-mean+(numSTD*std)
		nums<-seq(low, high, 0.02)
		if (i%%2==0) ts=-0.02 else ts=0.02
		rug (nums, side=2, col=colors[i+1], ticksize=ts)
	}
}


