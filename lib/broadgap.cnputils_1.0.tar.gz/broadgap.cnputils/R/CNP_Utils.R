#return the cnp names the exist in at least one cluster result list.
cnpUtils.getUniqueCNPNames<-function (dataList) {
     sort (unique (as.vector (unlist (sapply (dataList, function (a) which (sapply (a, function (x) !is.null(x))))))))
     
}

#given a matrix/dataframe of data for some property of a CNP, extract one line of it and split it into plates.  The result is a list of named vectors, one per plate, sorted by plateName.  This depends on the data being labeled by
#the header to match is which column in the platemap file matches to the identifiers in the dataframe.
cnpUtils.getCNPDataByPlate<-function (dataFrame, cnpName, plateMap, matchLabel="cel") {
	oneCNPLine<-dataFrame[cnpName,]
	a<-cnpUtils.getOneCNPLineByPlate(oneCNPLine, plateMap)
	return (a)
}

#For a single line from a data frame that contains the names of the samples that match the plateMap, get a list of plate names with the appropriate sub vector from the matrix 
#the matchLabel is which column in the platemap file matches to the identifiers in the dataframe.
cnpUtils.getOneCNPLineByPlate<-function (oneCNPLine, plateMap, matchLabel="cel") {

	idx<-match (names(oneCNPLine), plateMap[[matchLabel]])
	plateNames<-as.vector (sort (unique (plateMap[idx,]$plate)))
	result<-list()
	for (i in 1:length (plateNames)) {
		p<-plateNames[i]
		labelList<-plateMap[plateMap$plate==p,][[matchLabel]]
		idx2<-match(labelList, names(oneCNPLine))
		idx2<-idx2[!is.na(idx2)]
		idx2<-unique(idx2)
		result[[p]]= oneCNPLine[idx2]
	}
	return (result)
}



#if you got a data list from getOneCNPLineByPlate, you can convert it back to a matrix here.
cnpUtils.dataListToVector <-function (dataList) {
	result<-c()
	for (i in 1:length(dataList)) result<-c(result, dataList[[i]])  
   	return (result)
}
	

#Utility method to get the number of probes for each CNP.
#This produces a data frame 
cnpUtils.getProbeCountsForCNPs<- function (smartProbeFile) {
	a<-readSmartProbeFile(smartProbeFile)
	cnpNames<-unique (a$wh)
	getCount<-function (cnpName, smartProbeData) length (which (a$wh==cnpName))
	counts<-sapply (cnpNames, getCount)	
	data.frame (cnp_id=cnpNames, count=counts, stringsAsFactors=F)
}


cnpUtils.alignTwoDataSets<-function (dataFrame, dependantDF) {
	
	missingDependentSamples<-setdiff(colnames(dataFrame), colnames(dependantDF))

	if (length(missingDependentSamples)>0) print (paste ("assignment matrix had samples that were not in intensity file: ", missingDependentSamples))
	
	depend<-dependantDF[rownames(dataFrame),colnames(dataFrame)]
	
	result<-list(data= dataFrame, dependant=depend, missingSamples=missingDependentSamples)
	return (result)
}

#takes a data frame with CEL labels, and converts them to sample labels.
#this expects that the data frame plateMap has a cel and sample column.
cnpUtils.convertCelToSample<-function (dataFrame, plateMap) {
	if (is.null(plateMap)) {
		print ("No platemap file given, labels not changed to sample names")
		return (dataFrame)
	}
	allSampleNames<-c()
	
	totalSampleCount<-0
	celNames<-colnames(dataFrame)
	idx<-match (celNames, plateMap$cel)
	failedMaps<-which(is.na(idx))
	if (length (failedMaps)>0) {
	    for (fm in failedMaps) {
			print (paste ("Mapping failed for profile cel ", celNames[fm], sep=" "))
		 }
	}
	 	
	newNames<-plateMap[idx,][["sample"]]
	if (length(newNames) < length(unique(newNames))) 
		print ("Not all samples were uniquely named.  This will cause problems")
		
	colnames(dataFrame)<-newNames	
	return (dataFrame)
	
}
	
#produces an empty matrix that has the same dimensions and row/column names as the original.
cnpUtils.cloneMatrix<-function (x) {
	result<-matrix(rep(NA, dim(x)[1]*dim(x)[2]), nrow=dim(x)[1], ncol=dim(x)[2], dimnames=list(rownames(x), colnames(x)))
}

cnpUtils.sortCNPListNames<-function (cnpList) {
           temp<-sapply (cnpList, function (x) as.numeric (substr(x, 4, nchar(x))))
           r<-cnpList [sort (temp, index.return=T)$ix]
           cat ("sorted CNVS", '\n')
           return (r)
}

